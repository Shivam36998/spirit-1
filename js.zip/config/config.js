const sessionSecret="mySecreat";
const userEmail="";
const userPassword="Surajphe20@";





 




export {sessionSecret,userEmail,userPassword}