function myFunctionshow() {
    var elem = document.getElementsByClassName("nav-items");
    elem[0].style.display="block";
  }
  function myFunctionhide() {
    var elem = document.getElementsByClassName("nav-items");
    elem[0].style.display="none";
  }
//   if(window.screen.width<768){
//   window.onclick=function(event){
//     if(!event.target.matches('#bar-button')){
//     var elem = document.getElementsByClassName("nav-items");
//     elem[0].style.display="none";
//     }
//   }
// }